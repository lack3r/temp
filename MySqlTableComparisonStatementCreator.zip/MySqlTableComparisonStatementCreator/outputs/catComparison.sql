select if(!isnull(table_A.id) and !isnull(table_B.id),'BOTH', if(isnull(table_A.id),'table_B','table_A')) as _source,  
CONCAT(
if(table_A.`Name` <> table_B.`Name`, CONCAT(' [','table_A.`Name`', table_A.`Name`, ' : ', 'table_B.`Name`', table_B.`Name`,'] '),''), 
if(table_A.`Surname` <> table_B.`Surname`, CONCAT(' [','table_A.`Surname`', table_A.`Surname`, ' : ', 'table_B.`Surname`', table_B.`Surname`,'] '),''), 
if(table_A.`Country` <> table_B.`Country`, CONCAT(' [','table_A.`Country`', table_A.`Country`, ' : ', 'table_B.`Country`', table_B.`Country`,'] '),''), 
if(ABS(table_A.`DailyFoodCost` - table_B.`DailyFoodCost`) > 1.0E-5, CONCAT(' [','table_A.`DailyFoodCost`', table_A.`DailyFoodCost`, ' : ', 'table_B.`DailyFoodCost`', table_B.`DailyFoodCost`,'] '),''))
as Differences,  
table_A.*, table_B.* 
FROM 
	(SELECT `Name`, `Surname`, `Country`, `DailyFoodCost` 
	FROM MY_DATABASE.cats) as table_A 
LEFT JOIN  
	(SELECT `Name`, `Surname`, `Country`, `DailyFoodCost` 
	FROM OTHER_DATABASE.cats) as table_B 
on table_A.id = table_B.id 
where 
table_A.`Name` <> table_B.`Name` OR table_A.`Surname` <> table_B.`Surname` OR table_A.`Country` <> table_B.`Country` OR ABS(table_A.`DailyFoodCost` - table_B.`DailyFoodCost`) > 1.0E-5 OR isnull(table_A.id) OR isnull(table_B.id) 
 
UNION 
 
select if(!isnull(table_A.id) and !isnull(table_B.id),'BOTH', if(isnull(table_A.id),'table_B','table_A')) as _source,  
CONCAT(
if(table_A.`Name` <> table_B.`Name`, CONCAT(' [','table_A.`Name`', table_A.`Name`, ' : ', 'table_B.`Name`', table_B.`Name`,'] '),''), 
if(table_A.`Surname` <> table_B.`Surname`, CONCAT(' [','table_A.`Surname`', table_A.`Surname`, ' : ', 'table_B.`Surname`', table_B.`Surname`,'] '),''), 
if(table_A.`Country` <> table_B.`Country`, CONCAT(' [','table_A.`Country`', table_A.`Country`, ' : ', 'table_B.`Country`', table_B.`Country`,'] '),''), 
if(ABS(table_A.`DailyFoodCost` - table_B.`DailyFoodCost`) > 1.0E-5, CONCAT(' [','table_A.`DailyFoodCost`', table_A.`DailyFoodCost`, ' : ', 'table_B.`DailyFoodCost`', table_B.`DailyFoodCost`,'] '),''))
as Differences,  
table_A.*, table_B.* 
FROM 
	(SELECT `Name`, `Surname`, `Country`, `DailyFoodCost` 
	FROM MY_DATABASE.cats) as table_A 
RIGHT JOIN  
	(SELECT `Name`, `Surname`, `Country`, `DailyFoodCost` 
	FROM OTHER_DATABASE.cats) as table_B 
on table_A.id = table_B.id 
where 
table_A.`Name` <> table_B.`Name` OR table_A.`Surname` <> table_B.`Surname` OR table_A.`Country` <> table_B.`Country` OR ABS(table_A.`DailyFoodCost` - table_B.`DailyFoodCost`) > 1.0E-5 OR isnull(table_A.id) OR isnull(table_B.id);