package com.aloizou.mysqlcomparisonhelpers;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class TablesConfigurationsXMLReader {

	private static final Logger logger = Logger.getLogger(ColumnNameLoader.class);
	
	public TablesConfigurationsXMLReader() {}
	
	public List<ITableConfiguration> ReadXML(String fileName) {

		List<ITableConfiguration> tableConfigurations = new LinkedList<>();
		try {
			File inputFile = new File(fileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("TableComparison");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) nNode;
					ITableConfiguration tableConfiguration = readTableConfiguration(element);
					tableConfigurations.add(tableConfiguration);
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured while reading XML", e);
		}
		
		return tableConfigurations;
	}
	
	private ITableConfiguration readTableConfiguration(Element element) {
		String firstTableName = element.getElementsByTagName("FirstTableName").item(0).getTextContent();
		String secondTableName = element.getElementsByTagName("SecondTableName").item(0).getTextContent();
		String firstTableAlias = element.getElementsByTagName("FirstTableAlias").item(0).getTextContent();
		String secondTableAlias = element.getElementsByTagName("SecondTableAlias").item(0).getTextContent();
		String primaryKey = element.getElementsByTagName("PrimaryKey").item(0).getTextContent();
		String columnsFilename = element.getElementsByTagName("ColumnsFileName").item(0).getTextContent();
		String columnsInDoublesFilename = element.getElementsByTagName("ColumnsInDoublesFileName").item(0).getTextContent();
		String outputFileName = element.getElementsByTagName("OutputFileName").item(0).getTextContent();
		
		return new TableConfiguration(firstTableName, secondTableName, firstTableAlias, secondTableAlias, primaryKey, columnsFilename, columnsInDoublesFilename, outputFileName);
		
	}
}
