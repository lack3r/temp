package com.aloizou.mysqlcomparisonhelpers;

import java.util.List;
import java.util.Set;
import java.util.StringJoiner;

public class TableComparisonStatementCreator {
	private static final double DOUBLE_EPSILON = 0.00001D;
	
	public String createStatement(ITableConfiguration config) {
		
		StringJoiner js = new StringJoiner(" \r\n", "", ";");
		ColumnNameLoader columnNameLoader = new ColumnNameLoader();
		List<String> columns = columnNameLoader.loadAllColumns(config.getFileName());
		
		Set<String> columnsDouble = columnNameLoader.getDoublesColumnsSet(config.getFileNameDoubles());

		fillQuery(js, config, columns, columnsDouble, "LEFT");
		js.add("");
		js.add("UNION");
		js.add("");
		fillQuery(js, config, columns, columnsDouble, "RIGHT");

		return js.toString();
	}

	private void fillQuery(StringJoiner js, ITableConfiguration config, List<String> columns, Set<String> columnsDoubles,
			String joinType) {

		js.add(getSourceColumn(config));
		js.add(getDifferenceColumn(columns, columnsDoubles, config));
		js.add(columnOfTable(config.getFirstTableShortName(), "*") + ", "
				+ columnOfTable(config.getSecondTableShortName(), "*"));

		js.add("FROM");
		js.add("\t(SELECT " + getColumnList(columns) + "\tFROM " + config.getFirstTableName() + ") as "
				+ config.getFirstTableShortName());
		js.add(joinType + " JOIN ");
		js.add("\t(SELECT " + getColumnList(columns) + "\tFROM " + config.getSecondTableName() + ") as "
				+ config.getSecondTableShortName());
		js.add("on " + columnOfTable(config.getFirstTableShortName(), config.getPrimaryKey()) + " = "
				+ columnOfTable(config.getSecondTableShortName(), config.getPrimaryKey()));
		js.add("where");
		js.add(getWhereClause(columns, columnsDoubles, config));
	}

	private String getDifferenceColumn(List<String> columns, Set<String> columnsDouble, ITableConfiguration config) {
		StringJoiner js = new StringJoiner(", \r\n", "CONCAT(\r\n", ")\r\nas Differences, ");

		for (String column : columns) {
			getDifferenceColumnEntry(config, column, columnsDouble.contains(column.toUpperCase().replace("`", "")), js);
		}
		
		return js.toString();
	}

 private void getDifferenceColumnEntry(ITableConfiguration config, String column, boolean isDouble, StringJoiner js) {
	 String fieldDifference = "";

		fieldDifference = "if(" + comparisonOfSingleField(config, column,isDouble) + ", CONCAT(' ['," + "'"
				+ columnOfTable(config.getFirstTableShortName(), column) + "', "
				+ columnOfTable(config.getFirstTableShortName(), column) + ", ' : ', " + "'"
				+ columnOfTable(config.getSecondTableShortName(), column) + "', "
				+ columnOfTable(config.getSecondTableShortName(), column) + ",'] '" + "),'')";
		js.add(fieldDifference);
 }
 
	private String comparisonOfSingleField(ITableConfiguration config, String column, boolean isDouble)
	{
		String result;
		if(!isDouble) {
			result = columnOfTable(config.getFirstTableShortName(), column) + " <> "
					+ columnOfTable(config.getSecondTableShortName(), column);
		}
		else {
			result = "ABS("+columnOfTable(config.getFirstTableShortName(), column)+" - "+columnOfTable(config.getSecondTableShortName(), column)+") > "+DOUBLE_EPSILON;
		}
		
		return result;
	}	
	private String getWhereClause(List<String> columns, Set<String> columnsDoubles, ITableConfiguration config) {
		StringJoiner js = new StringJoiner(" OR ", "", "");
		columns.forEach(c -> js.add(comparisonOfSingleField(config, c,columnsDoubles.contains(c.toUpperCase().replace("`", "")))));
		js.add("isnull(" + columnOfTable(config.getFirstTableShortName(), config.getPrimaryKey()) + ")");
		js.add("isnull(" + columnOfTable(config.getSecondTableShortName(), config.getPrimaryKey()) + ")");
		return js.toString();
	}

	private String getSourceColumn(ITableConfiguration config) {
		return "select if(!isnull(" + columnOfTable(config.getFirstTableShortName(), config.getPrimaryKey())
				+ ") and !isnull(" + columnOfTable(config.getSecondTableShortName(), config.getPrimaryKey())
				+ "),'BOTH', if(isnull(" + columnOfTable(config.getFirstTableShortName(), config.getPrimaryKey()) + "),"
				+ "'" + config.getSecondTableShortName() + "','" + config.getFirstTableShortName() + "')) as _source, ";
	}

	private String columnOfTable(String table, String column) {
		return table + "." + column;
	}

	private String getColumnList(List<String> columns) {
		StringJoiner js = new StringJoiner(", ", "", " \r\n");

		columns.forEach(js::add);

		return js.toString();
	}
}
