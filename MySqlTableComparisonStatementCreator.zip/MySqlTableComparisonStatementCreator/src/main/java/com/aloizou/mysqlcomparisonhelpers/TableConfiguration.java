package com.aloizou.mysqlcomparisonhelpers;

public class TableConfiguration implements ITableConfiguration {

	private final String firstTableName;
	private final String secondTableName;
	private final String firstTableShortName;
	private final String secondTableShortName;
	private final String primaryKey;
	private final String filename;
	private final String filenameDoubles;
	private final String outputFileName;

	public TableConfiguration(String firstTableName, String secondTableName, String firstTableShortName,
			String secondTableShortName, String primaryKey, String filename, String filenameDoubles, String outputFileName) {
		this.firstTableName = firstTableName;
		this.secondTableName = secondTableName;
		this.firstTableShortName = firstTableShortName;
		this.secondTableShortName = secondTableShortName;
		this.primaryKey = primaryKey;
		this.filename = filename;
		this.filenameDoubles = filenameDoubles;
		this.outputFileName = outputFileName;
	}

	public String getFirstTableName() {
		return firstTableName;
	}

	public String getSecondTableName() {
		return secondTableName;
	}

	public String getFirstTableShortName() {
		return firstTableShortName;
	}

	public String getSecondTableShortName() {
		return secondTableShortName;
	}

	public String getPrimaryKey() {
		return primaryKey;
	}

	public String getFileName() {
		return filename;
	}
	public String getFileNameDoubles() {
		return filenameDoubles;
	}
	public String getOutputFileName() {
		return outputFileName;
	}
}
