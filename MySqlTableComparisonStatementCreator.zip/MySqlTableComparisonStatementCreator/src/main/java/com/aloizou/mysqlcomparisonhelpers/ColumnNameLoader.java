package com.aloizou.mysqlcomparisonhelpers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

public class ColumnNameLoader {

	private static final Logger logger = Logger.getLogger(ColumnNameLoader.class);
	private static final String WHITESPACE = "\\s+";
	
	public List<String> loadAllColumns(String filename) {

		List<String> columns = new LinkedList<>();
		Function<String, String> stringTransformation = s -> s;
		
		load(filename, columns, stringTransformation);
		
		return columns;
	}
	
	public Set<String> getDoublesColumnsSet(String filename) {

		Set<String> columns = new HashSet<>();
		Function<String, String> stringTransformation = s -> s.toUpperCase().replace("`", "");

		load(filename, columns, stringTransformation);
		
		return columns;
	}
	
	private void load(String filename, Collection<String> collection, Function<String, String> stringTransformation) {
		
		// To get the file from the resources folder
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("Columns/"+filename).getFile());

		//To get a stream of all words
		try (Stream<String> stream =  Files.lines(file.toPath()).flatMap(Pattern.compile(WHITESPACE)::splitAsStream)) {

			stream.forEach(s -> collection.add(stringTransformation.apply(s)));

		} catch (IOException e) {
			logger.error("Could not read columns file", e);
		}
	}
}
