package com.aloizou.mysqlcomparisonhelpers;

public interface ITableConfiguration {

	public String getFirstTableName();

	public String getSecondTableName();

	public String getFirstTableShortName();

	public String getSecondTableShortName();

	public String getPrimaryKey();

	public String getFileName();

	public String getFileNameDoubles();
	
	public String getOutputFileName();
}
