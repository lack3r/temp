package com.aloizou.mysqlcomparisonhelpers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * SQLTableComparatorQueryCreator
 *
 */
public class MultibleTableComparisonStatementCreator {

	private static final Logger logger = Logger.getLogger(MultibleTableComparisonStatementCreator.class);
	private static final String OUTPUTS_DIRECTORY = "./outputs/";
	private static final String TABLES_CONFIGURATIONS_FILE = "TablesConfigurations.xml";

	public static void main(String[] args) {

		TableComparisonStatementCreator comparisonStatementCreator = new TableComparisonStatementCreator();

		logger.info("MultiComparisonStatementCreator process started");
		
		// To get the file from the resources folder
		ClassLoader classLoader = MultibleTableComparisonStatementCreator.class.getClassLoader();
				
		List<ITableConfiguration> tableConfigurations = new TablesConfigurationsXMLReader().ReadXML(classLoader.getResource(TABLES_CONFIGURATIONS_FILE).getFile());
		for (final ITableConfiguration tableConfiguration : tableConfigurations) {
			String statement = comparisonStatementCreator.createStatement(tableConfiguration);
			Path path = Paths.get(OUTPUTS_DIRECTORY + tableConfiguration.getOutputFileName());
			
			try {
				Files.write(path, statement.getBytes());
				logger.info(tableConfiguration.getOutputFileName() + " created successfully");
			} catch (IOException e) {
				logger.error("Could not write to file" + path, e);
			}
		}
		logger.info("MultiComparisonStatementCreator process finished");
	}
}
